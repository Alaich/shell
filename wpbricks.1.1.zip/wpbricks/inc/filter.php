<?php
/**
 * File include all the filters.
 *
 * @package wpbricks
 */

/*
 * Add filter for expert more
 */
add_filter( 'excerpt_more', 'wpbricks_excerpt_more' );
